import React from 'react'

function EmployeePageDash() {
  return (
    <div>
      <h1>EmployeePageDash</h1>
    </div>
  )
}

export default EmployeePageDash
