import React from 'react'

function SaleSummaryPageDash() {
  return (
    <div>
      <h1>SaleSummaryPageDash</h1>
    </div>
  )
}

export default SaleSummaryPageDash
