import React from 'react'

function EmployeeDash() {
  return (
    <div>
      <h1>EmployeeDash</h1>
    </div>
  )
}

export default EmployeeDash
