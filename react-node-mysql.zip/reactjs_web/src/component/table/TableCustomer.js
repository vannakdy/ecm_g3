

function TableCustomer() {
  return (
   <div></div>
  );
}

export default TableCustomer;