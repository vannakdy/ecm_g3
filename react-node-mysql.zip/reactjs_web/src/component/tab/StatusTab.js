
import TableCustomer from '../table/TableCustomer';
import ProductList from '../list/ProductList';
import { useState } from 'react';

function StatusTab() {
  const [p,setP] = useState([2,4,5,6,7,8])
  return (
    <div></div>
  );
}

export default StatusTab;