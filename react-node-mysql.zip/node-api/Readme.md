
# init 
    > npm init
# install express
    > npm install express