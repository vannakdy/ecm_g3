

function HomePage(){

    return(
        <div>
            <h1>HomePage dashboard</h1>
        </div>
    )
}

export default HomePage;