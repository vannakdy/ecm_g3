
function OrderPage(){

    return(
        <div>
            <h1>OrderPage</h1>
        </div>
    )
}

export default OrderPage;