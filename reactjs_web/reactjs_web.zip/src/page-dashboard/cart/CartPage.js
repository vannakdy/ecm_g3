

function CartPage(){

    return(
        <div>
            <h1>CartPage</h1>
        </div>
    )
}

export default CartPage;