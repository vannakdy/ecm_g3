
function PorductPage(){

    return(
        <div>
            <h1>PorductPage</h1>
        </div>
    )
}

export default PorductPage;