

function CustomerPage(){

    return(
        <div>
            <h1>CustomerPage</h1>
        </div>
    )
}

export default CustomerPage;